#' Fit basic statistical models to climate data
#'
#' @param obj An object of class \code{climr} from \code{\link{load_clim}}
#' @param fit_arg The type of model required, either Gaussian regression with 4 optimization procedures
#'
#' @return Returns a list of class \code{climr_gp_fit}
#' @seealso \code{\link{load_clim}}, \code{\link{plot.climr_fit}}
#' @export
#' @importFrom magrittr "%$%"
#'
#' @examples




gp_fit.climr <- function(obj, arg = c("Nelder-Mead", "BFGS", "SANN", "Brent"))  {


 # Create global variables to avoid annoying CRAN notes
 DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = x = year = NULL

 # Find what type of fitting method
 fit_arg <- match.arg(arg)

 x = scale(obj$clim_year$year)[,1]
 y = scale(obj$clim_year$temp)[,1]
 x_g = pretty(x, n = 100)
p = 1


 # Create design matrices
 x_rep = matrix(rep(x, p+1), ncol = (p+1), nrow = length(x))
 X = sweep(x_rep, 2, 0:p, '^')
 X_g_rep = matrix(rep(x_g, p+1), ncol = (p+1), nrow = length(x_g))
 X_g = sweep(X_g_rep, 2, 0:p, '^')

 gp_criterion <- function(p= c(0,0,0), x = scale(obj$clim_year$year)[,1], y= scale(obj$clim_year$temp)[,1]) {
   sig_sq <- exp(p[1])
   rho_sq <- exp(p[2])
   tau_sq <- exp(p[3])
   Mu <- rep(0, length(x))
   Sigma <- sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))
   ll <- dmvnorm(y, Mu, Sigma, log = TRUE)
   return(-ll)
 }


 if(fit_arg == 'Nelder-Mead') { answer_NM <- optim(rep(0, 3), gp_criterion, method = 'Nelder-Mead')
 sig_sq = exp(answer_NM$par[1])
 rho_sq = exp(answer_NM$par[2])
 tau_sq = exp(answer_NM$par[3])
 mod = gp_criterion(p = answer_NM$par)
 }




 else if(fit_arg == 'BFGS') { answer_BFGS <- optim(rep(0, 3), gp_criterion, x = x, y = y, method = 'BFGS')
 sig_sq = exp(answer_BFGS$par[1])
 rho_sq = exp(answer_BFGS$par[2])
 tau_sq = exp(answer_BFGS$par[3])
 mod = gp_criterion(answer_BFGS$par)
 }


 else if(fit_arg == "SANN") { answer_SANN <- optim(rep(0, 3), gp_criterion, method = 'SANN')
 sig_sq = exp(answer_SANN$par[1])
 rho_sq = exp(answer_SANN$par[2])
 tau_sq = exp(answer_SANN$par[3])
 mod <- gp_criterion(answer_SANN$par)
 }


 else if(fit_arg == "Brent") { answer_Brent <- optim(c(0,0,0), gp_criterion, method = 'Brent')
 sig_sq = exp(answer_SANN$par[1])
 rho_sq = exp(answer_SANN$par[2])
 tau_sq = exp(answer_SANN$par[3])
 mod <- gp_criterion(answer_SANN$par)
 }

 #Cov matrix

 C = sig_sq * exp( - rho_sq * outer(x_g, x, '-')^2 )
 Sigma = sig_sq * exp( - rho_sq * outer(x, x, '-')^2 ) + tau_sq * diag(length(x))

 #PREDICTION
 pred_gp = C %*% solve(Sigma, y)

 class(pred_gp) <- 'climr_gp_fit'

 return(pred_gp)
}

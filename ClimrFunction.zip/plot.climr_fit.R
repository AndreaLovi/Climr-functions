#' Plot climr output
#'
#' @param x Output from the \code{\link{fit}} function
#' @param time_grid An optional time grid over which to produce fitted values of the model
#' @param ... Other arguments to plot (not currently implemented)
#'
#' @return Nothing: just a nice plot
#' @seealso \code{\link{load_clim}}, \code{\link{fit}}
#' @export
#' @import ggplot2
#' @importFrom stats "predict"
#' @importFrom tibble "tibble"
#' @importFrom viridis "scale_color_viridis"
#'
#' @examples
#' data1 = load_clim('SH')
#' data2 = gp_fit.climr(data1, fit_type = 'smooth.spline')
#' plot.climr_fit(data2)

plot.climr_fit <- function(x, time_grid = pretty(scale(data1$clim_year$year),n = 100), ...) {

  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = year = NULL

  Gaussian1 = x *0.39461 + 0.05604
  Gaussian2 = c(pretty(data1$clim_year$year,n = 70), 2020)

  ggplot()+
  geom_point(aes(data1$clim_year$year , data1$clim_year$temp))+
  geom_line(aes(Gaussian2,Gaussian1))+
    theme_bw()+
    xlab('Year')+
    ylab('Temperature anomaly')+
    theme(legend.position = 'None')+
 scale_color_viridis()

  }
